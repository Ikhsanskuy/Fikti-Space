<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <!-- <img src="" alt="logo"  !important> -->
    <a href="../index.php"><img src="../../assets/img/logo copy.png" style="width: 150px;"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
        <div class="navbar-nav">
            <a class="nav-item nav-link text-danger float-right" href="../../config/logout.php">logout</a>
        </div>
    </div>
</nav>